const mysql = require("mysql");

const db = mysql.createConnection({
    host: 'localhost',
    database: 'ikea2',
    user: 'ikea2',
    port: 3306,
    password: 'Rm4HYepXGr4fTZTN'
  });



exports.db = db;